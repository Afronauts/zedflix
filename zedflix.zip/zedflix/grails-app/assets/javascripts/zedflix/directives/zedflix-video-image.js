//= wrapped

angular.module('zedflix').directive('zedflixVideoImage', function (uploadService, modalService, apiService, $stateParams) {
  return {
    restrict: 'E',
    templateUrl: '/zedflix/directive--zedflix-video-image.htm',
    scope: {
      video: '=',
      type: '@',
      size: '@'
    },
    link: function ($scope, $elem, $attrs) {

    }
  }
});
