//= wrapped

angular.module('zedflix').directive('zedflixProgressBar', function () {
  return {
    restrict: 'E',
    templateUrl: '/zedflix/directive--zedflix-progress-bar.htm',
    scope: {
      video: '=',
      hideTime: '@'
    },
    link: function ($scope, $elem, $attrs) {
      // $scope.videoObject = angular.merge({}, $scope.video);
      // $scope.videoObject.currentPlayTime = $scope.video.currentPlayTime || $scope.runtime;
      // $scope.videoObject.runtime = $scope.video.runtime || $scope.total;
    }
  }
});
