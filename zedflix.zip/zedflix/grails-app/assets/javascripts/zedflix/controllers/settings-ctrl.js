'use strict';

angular.module('zedflix').controller('settingsCtrl', ['$scope', 'apiService', 'modalService', '$rootScope', function ($scope, apiService, modalService, $rootScope) {

}]);




