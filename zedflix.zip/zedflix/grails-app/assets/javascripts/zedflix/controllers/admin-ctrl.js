'use strict';

angular.module('zedflix').controller('adminCtrl', ['$scope', 'apiService', 'modalService', '$rootScope', function ($scope, apiService, modalService, $rootScope) {

}]);




