//= wrapped

//= require /systaro/core/systaro.core
//= require /zedflix/core/zedflix.core
//= require /zedflix/zedflix.translations

//= require_self


//= require_tree services
//= require_tree controllers
//= require_tree directives
//= require_tree domain
//= require_tree filters
//= require_tree templates

//= require zedflix.run
//= require zedflix.routes
//= require zedflix.interceptor

angular.module('zedflix', [
    'systaro.core',
    'zedflix.core',
    'zedflix.translations',
    'ui.router',
    'ui.bootstrap',
    'ngFileUpload',
    'ui.slider',
    'LocalStorageModule',
    'ui.select',
    'ngSanitize'
]);



angular.module('zedflix').config(function ($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/dash');
});




