//= wrapped

//= require /systaro/core/systaro.core
//= require /zedflix/zedflix.translations

//= require_self

angular.module('zedflixPublic', [
    'systaro.core',
    'zedflix.translations'
]);




