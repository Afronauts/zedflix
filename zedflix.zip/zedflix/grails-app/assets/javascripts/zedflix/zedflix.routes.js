//= wrapped


angular.module('zedflix').config(function ($stateProvider) {

	$stateProvider

		//BASE ROUTES
		.state('dash', {
			url: '/dash?genreId?mediaModal?mediaType',
			templateUrl: '/zedflix/dash.htm',
			controller: 'dashCtrl as vm',
			reloadOnSearch: false,
			resolve: {
				currentUser: resolveCurrentUser
			}
		})

		.state('player', {
			url: '/player/:videoId?currentTime?sessionId',
			templateUrl: '/zedflix/player.htm',
			controller: 'playerCtrl',
			resolve: {
				currentUser: resolveCurrentUser
			}
		})
		.state('sub-profiles', {
			url: '/sub-profiles',
			templateUrl: '/zedflix/sub-profiles.htm',
			controller: 'subProfilesCtrl'
		})

		.state('userSettings', {
			url: '/user-settings',
			templateUrl: '/zedflix/user-settings.htm',
			controller: 'userSettingsCtrl',
			resolve: {
				currentUser: resolveCurrentUser
			}
		})

		.state('help', {
			url: '/help',
			templateUrl: '/zedflix/help.htm',
			controller: 'helpCtrl'
		})


		//ADMIN ROUTES
		.state('admin', {
			url: '/admin',
			templateUrl: '/zedflix/admin.htm',
			controller: 'adminCtrl',
			resolve: {
				currentUser: checkPermission
			}
		})
		.state('admin.fileManager', {
			url: '/fileManager',
			templateUrl: '/zedflix/admin-fileManager.htm',
			controller: 'adminFileManagerCtrl'
		})
		.state('admin.movies', {
			url: '/movies',
			templateUrl: '/zedflix/admin-movies.htm',
			controller: 'adminMoviesCtrl as vm'
		})
		.state('admin.movie', {
			url: '/movie/:movieId',
			templateUrl: '/zedflix/admin-movie.htm',
			controller: 'adminMovieCtrl'
		})
		.state('admin.videos', {
			url: '/videos',
			templateUrl: '/zedflix/admin-videos.htm',
			controller: 'adminVideosCtrl'
		})
		.state('admin.video', {
			url: '/video/:videoId',
			templateUrl: '/zedflix/admin-video.htm',
			controller: 'adminVideoCtrl'
		})

		.state('admin.notifications', {
			url: '/notifications',
			templateUrl: '/zedflix/admin-notifications.htm',
			controller: 'adminNotificationsCtrl',
			resolve: {
				currentUser: checkPermissionAdmin
			}
		})

		.state('admin.newReleases', {
			url: '/newReleases',
			templateUrl: '/zedflix/admin-new-releases.htm',
			controller: 'adminNewReleasesCtrl'
		})
		.state('admin.shows', {
			url: '/shows',
			templateUrl: '/zedflix/admin-shows.htm',
			controller: 'adminShowsCtrl'
		})
		.state('admin.show', {
			url: '/show/:showId?episodeId?season',
			templateUrl: '/zedflix/admin-show.htm',
			controller: 'adminShowCtrl'
		})
    .state('admin.reports', {
      url: '/reports',
      templateUrl: '/zedflix/admin-reports.htm',
      controller: 'adminReportsCtrl',
      controllerAs: "vm"
    })



		//SETTINGS ROUTES
		.state('settings.users', {
			url: '/users',
			templateUrl: '/zedflix/settings-users.htm',
			controller: 'settingsUsersCtrl',
			resolve: {
				currentUser: checkPermissionAdmin
			}
		})
		.state('settings.userActivity', {
			url: '/user-activity',
			templateUrl: '/zedflix/settings-user-activity.htm',
			controller: 'settingsUserActivityCtrl',
      controllerAs: 'vm',
			resolve: {
				currentUser: checkPermissionAdmin
			}
		})
		.state('settings.settings', {
			url: '/settings',
			templateUrl: '/zedflix/settings-settings.htm',
			controller: 'settingsSettingsCtrl',
			resolve: {
				currentUser: checkPermissionAdmin
			}
		})

		.state('settings', {
			url: '/settings',
			templateUrl: '/zedflix/settings.htm',
			controller: 'settingsCtrl',
			resolve: {
				currentUser: checkPermission
			}
		});


	function resolveCurrentUser(apiService, $rootScope) {
		return apiService.currentUser().then(function (response) {
			var data = response.data;
			if(!data){
				location.href = '/login/auth'
			}

			if (data) {
				$rootScope.currentUser = data;
				return data;
			}
		}, function (err, status) {
      if(status === 401){
        location.href = '/login/auth?sessionExpired=true'
      }
    });
	}

	function checkPermissionAdmin(apiService, $rootScope, $state) {
		return apiService.currentUser().then(function (response) {
			var data = response.data;
			if(!data){
				location.href = '/login/auth'
			}
			if (data.isAdmin) {
				$rootScope.currentUser = data;
				return data;
			} else {
				$state.go('dash');
			}
		});
	}

	function checkPermission(apiService, $rootScope, $state) {
		return apiService.currentUser().then(function (response) {
			var data = response.data;
			if(!data){
				location.href = '/login/auth'
			}
			if (data && data.authorities.length) {
				$rootScope.currentUser = data;
				return data;
			} else {
				$state.go('dash');
			}
		});
	}

});

