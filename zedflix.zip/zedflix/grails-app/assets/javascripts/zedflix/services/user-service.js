'use strict';

angular.module('zedflix').factory('userService', function ($rootScope, $translate) {
	return {
		setCurrentUser: function (data) {
			$rootScope.currentUser = data;
		}
	};
});
