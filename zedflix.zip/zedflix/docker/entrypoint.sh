#!/bin/sh
java -Dgrails.env=$ACTIVE_PROFILE -jar streama.jar
